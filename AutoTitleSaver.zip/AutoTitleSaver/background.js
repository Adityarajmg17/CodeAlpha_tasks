let allTitles = "";

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.title) {

        allTitles += tab.title + "\n";

        let dataUrl = "data:text/plain;charset=utf-8," + 
                      encodeURIComponent(allTitles);

        chrome.downloads.download({
            url: dataUrl,
            filename: "titles.txt",
            conflictAction: "overwrite",
            saveAs: false
        });
    }
});
