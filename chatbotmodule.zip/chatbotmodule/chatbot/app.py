from flask import Flask, render_template, request, jsonify
import json
import datetime

app = Flask(__name__)

# Load Q&A file
with open("qa.json") as f:
    qa_data = json.load(f)

def chatbot_reply(message):
    message = message.lower()

    # Check in Q&A file first
    for question in qa_data:
        if question in message:
            return qa_data[question]

    # Extra dynamic replies
    if "time" in message:
        return datetime.datetime.now().strftime("%H:%M:%S")

    if "date" in message:
        return str(datetime.date.today())

    return "Sorry, I don't understand that."

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json["message"]
    reply = chatbot_reply(user_message)
    return jsonify({"reply": reply})

if __name__ == "__main__":
    app.run(debug=True)
