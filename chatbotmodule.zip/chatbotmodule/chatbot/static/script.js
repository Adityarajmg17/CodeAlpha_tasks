const chatBtn = document.getElementById("chatBtn");
const chatbox = document.getElementById("chatbox");
const closeBtn = document.getElementById("closeBtn");
const messages = document.getElementById("messages");

chatBtn.onclick = () => chatbox.style.display = "flex";
closeBtn.onclick = () => chatbox.style.display = "none";

function sendMessage() {
    let input = document.getElementById("userInput");
    let msg = input.value;
    if (msg === "") return;

    messages.innerHTML += `<p><b>You:</b> ${msg}</p>`;

    fetch("/chat", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({message: msg})
    })
    .then(res => res.json())
    .then(data => {
        messages.innerHTML += `<p><b>Bot:</b> ${data.reply}</p>`;
        messages.scrollTop = messages.scrollHeight;
    });

    input.value = "";
}
